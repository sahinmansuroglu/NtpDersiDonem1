﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Nakov.TurtleGraphics;
namespace Uyg3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int kenarUzunlugu = Convert.ToInt32(txtkenarUzunlugu.Text);
            int kenarSayisi = Convert.ToInt32(txtKenarSayisi.Text);
            int donmeAcisi = 360 / kenarSayisi;
            Turtle.Reset();
            Turtle.Delay = 250;
            for (int i = 0; i < kenarSayisi; i++)
            {
                Turtle.Forward(kenarUzunlugu);
                Turtle.Rotate(donmeAcisi);
            }
        }
    }
}
